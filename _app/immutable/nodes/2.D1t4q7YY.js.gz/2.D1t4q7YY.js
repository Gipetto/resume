import{t,a as i}from"../chunks/C87Zcp0E.js";import{c as e,n,r as p}from"../chunks/CgcDBB04.js";import{s as d}from"../chunks/D3bUsD92.js";var m=t('<div class="grid-single"><!></div>');function f(a,r){var o=m(),s=e(o);d(s,()=>r.children??n),p(o),i(a,o)}export{f as component};
//# sourceMappingURL=2.D1t4q7YY.js.map
