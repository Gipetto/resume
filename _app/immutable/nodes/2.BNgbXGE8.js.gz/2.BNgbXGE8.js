import{t,a as i}from"../chunks/CP9PUsVd.js";import{c as e,n,r as p}from"../chunks/ODu9BnlX.js";import{s as d}from"../chunks/CJbxx6dE.js";var m=t('<div class="grid-single"><!></div>');function f(a,r){var o=m(),s=e(o);d(s,()=>r.children??n),p(o),i(a,o)}export{f as component};
//# sourceMappingURL=2.BNgbXGE8.js.map
