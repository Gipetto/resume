import"../chunks/Bzak7iHL.js";import{f as i,e as n,b as e,d as t,n as d,r as p}from"../chunks/BnFemtiQ.js";var l=i('<div class="grid-single"><!></div>');function c(a,r){var o=l(),s=t(o);n(s,()=>r.children??d),p(o),e(a,o)}export{c as component};
//# sourceMappingURL=2.DxYfwEmf.js.map
