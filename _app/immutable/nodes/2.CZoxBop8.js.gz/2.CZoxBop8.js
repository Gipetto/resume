import{f as i,a as n}from"../chunks/Bq7WNI-n.js";import{c as t,n as p,r as e}from"../chunks/Bqrax_Mq.js";import{s as m}from"../chunks/DzuCijM0.js";var d=i('<div class="grid-single"><!></div>');function v(r,a){var o=d(),s=t(o);m(s,()=>a.children??p),e(o),n(r,o)}export{v as component};
//# sourceMappingURL=2.CZoxBop8.js.map
