import{b as p,E as t}from"./Bqrax_Mq.js";import{B as c}from"./qWShZZ1Y.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
//# sourceMappingURL=DzuCijM0.js.map
