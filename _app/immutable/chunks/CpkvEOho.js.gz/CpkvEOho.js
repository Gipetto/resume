var s;const a=((s=globalThis.__sveltekit_12lgger)==null?void 0:s.base)??"/resume";var e;const t=((e=globalThis.__sveltekit_12lgger)==null?void 0:e.assets)??a;export{t as a,a as b};
//# sourceMappingURL=CpkvEOho.js.map
