import{b as o,E as f,d as i,n as p,e as c,h as d,g as h}from"./ODu9BnlX.js";function _(r,s,...t){var n=r,e=p,a;o(()=>{e!==(e=s())&&(a&&(c(a),a=null),a=i(()=>e(n,...t)))},f),d&&(n=h)}export{_ as s};
//# sourceMappingURL=CJbxx6dE.js.map
