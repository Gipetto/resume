import{B as o,C as a,D as t,F as c,G as l}from"./Bqrax_Mq.js";function f(n){t===null&&o(),c&&t.l!==null?u(t).m.push(n):a(()=>{const e=l(n);if(typeof e=="function")return e})}function u(n){var e=n.l;return e.u??={a:[],b:[],m:[]}}export{f as o};
//# sourceMappingURL=C5g5wLGg.js.map
