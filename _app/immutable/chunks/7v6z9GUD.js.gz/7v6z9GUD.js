import{j as o,E as f,k as i,n as p,l as c,m as d,o as h}from"./Cauk6RRm.js";function E(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{E as s};
//# sourceMappingURL=7v6z9GUD.js.map
