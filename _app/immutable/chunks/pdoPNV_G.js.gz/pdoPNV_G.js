import{b as p,E as t}from"./kvD3EaN4.js";import{B as c}from"./BtCq2UWN.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
//# sourceMappingURL=pdoPNV_G.js.map
