import{l as o,a as r}from"../chunks/BGQpPwDh.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CU7xQj-h.js.map
