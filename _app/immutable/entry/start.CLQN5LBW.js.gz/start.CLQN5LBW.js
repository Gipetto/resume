import{l as o,a as r}from"../chunks/B_3R_1yE.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CLQN5LBW.js.map
