import{l as o,a as r}from"../chunks/Dri5ana8.js";export{o as load_css,r as start};
//# sourceMappingURL=start.C76ZbJlA.js.map
