import{l as o,a as r}from"../chunks/BV7OIWQa.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CGj_YT3R.js.map
