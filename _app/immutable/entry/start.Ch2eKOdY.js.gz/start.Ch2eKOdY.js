import{l as o,a as r}from"../chunks/BhQOaOG4.js";export{o as load_css,r as start};
//# sourceMappingURL=start.Ch2eKOdY.js.map
