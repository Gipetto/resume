import{l as o,a as r}from"../chunks/BBHbutXZ.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CxQxR8EN.js.map
