import{l as o,a as r}from"../chunks/DNzT-ox3.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CX93duHq.js.map
