import{l as o,a as r}from"../chunks/Bdd7ynGF.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BT02YWsw.js.map
