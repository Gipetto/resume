import{l as o,a as r}from"../chunks/DYSd7wi1.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BiTiJ2eZ.js.map
