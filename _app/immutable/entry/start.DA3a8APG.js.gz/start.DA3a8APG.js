import{l as o,a as r}from"../chunks/DmOarxks.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DA3a8APG.js.map
