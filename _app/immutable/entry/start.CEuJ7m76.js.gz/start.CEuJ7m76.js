import{l as o,a as r}from"../chunks/C3VC4eFs.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CEuJ7m76.js.map
