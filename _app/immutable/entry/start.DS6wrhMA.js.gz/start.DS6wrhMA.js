import{a as t}from"../chunks/1C3QhdU3.js";export{t as start};
//# sourceMappingURL=start.DS6wrhMA.js.map
