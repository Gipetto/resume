import{l as o,a as r}from"../chunks/643Tdp6k.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DOqQ52W0.js.map
