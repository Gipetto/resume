import{l as o,a as r}from"../chunks/CforFprT.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DokuRLj5.js.map
