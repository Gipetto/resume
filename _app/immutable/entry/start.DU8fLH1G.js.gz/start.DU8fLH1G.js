import{l as o,a as r}from"../chunks/DK-0PtiC.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DU8fLH1G.js.map
