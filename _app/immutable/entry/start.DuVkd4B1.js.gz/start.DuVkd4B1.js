import{l as o,a as r}from"../chunks/v7-Zeqdw.js";export{o as load_css,r as start};
//# sourceMappingURL=start.DuVkd4B1.js.map
